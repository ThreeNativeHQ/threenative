// Generated for you. Keep the six palette roles coherent when you repaint the arena.
export const palette = {
  skyHigh: 0x263449,
  skyLow: 0x090d13,
  arena: 0x18232d,
  player: 0x64d8cb,
  hostile: 0xff6b7a,
  accent: 0xf6c85f,
} as const;
